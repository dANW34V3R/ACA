Computes the factorial of R0 and stores the result in R3.
The stack is manually pushed to and poped from, storing the PC to return to and "function" arguments
The maximum valid input is 16, negatives give a value of 1
